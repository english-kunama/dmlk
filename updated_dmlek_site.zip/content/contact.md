---
title: "Contact Us"
slug: contact
---

# Contact Us

We welcome your questions, feedback and messages of support. Please fill out the form below and a representative from the Democratic Movement for the Liberation of the Eritrean Kunama (DMLEK) will get back to you.

<form action="mailto:info@example.com" method="post" enctype="text/plain" class="contact-form">
  <label for="name">Name</label><br />
  <input type="text" id="name" name="name" required /><br />
  <label for="email">Email</label><br />
  <input type="email" id="email" name="email" required /><br />
  <label for="message">Message</label><br />
  <textarea id="message" name="message" rows="5" required></textarea><br />
  <button type="submit">Send Message</button>
</form>