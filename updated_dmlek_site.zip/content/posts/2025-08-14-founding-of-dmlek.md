---
title: "Founding of DMLEK: A Response to Marginalization"
date: 2025-08-14
slug: founding-of-dmlek
summary: "The origin story of the Democratic Movement for the Liberation of the Eritrean Kunama (DMLEK) and its motivations."
---

# Founding of the Democratic Movement for the Liberation of the Eritrean Kunama (DMLEK)

The Democratic Movement for the Liberation of the Eritrean Kunama was officially established on **1 April 1995**. Eritrea had gained independence from Ethiopia only two years earlier, but the Kunama people – one of Eritrea’s nine ethnic groups – quickly realised that independence did not guarantee equal rights or autonomy.

DMLEK emerged in response to long‑standing **marginalisation and discrimination** faced by the Kunama community under successive Eritrean governments.  Its founders argued that self‑determination was the only way to safeguard the Kunama language, culture and ancestral lands.  While the movement uses political advocacy wherever possible, it is prepared to engage in armed resistance when dialogue fails.

Initially based in Ethiopia’s Afar Region, DMLEK drew support from Kunama refugees and the wider **Eritrean diaspora**.  Today it remains committed to building an inclusive Eritrea in which all ethnic groups enjoy equal rights and representation.