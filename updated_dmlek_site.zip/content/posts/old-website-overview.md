---
title: "Remembering the original DMLEK website"
date: 2025-08-17
summary: "An overview of key sections from the historical DMLEK website at mesel-biherat.com"
---

Before launching this modern site, the **Democratic Movement for the Liberation of the Eritrean Kunama (DMLEK)** maintained an online presence at **mesel‑biherat.com**.  That older Joomla‑based portal served as a hub for information about the movement and the Kunama people.  Here are some of its highlights:

* **About DMLEK and political program:**  The site offered a downloadable *political program* document outlining the movement’s aims for self‑determination, democracy and cultural preservation.  It emphasised that DMLEK was established in 1995 to defend the rights of the Kunama community and seek autonomy within Eritrea.

* **Kunama heritage:**  Visitors could explore pages about Kunama history, geography, economy and culture.  A map of the **ancestral land of the Kunama** provided geographic context, while articles explained traditions and social structures.

* **Media library:**  The portal hosted magazines, articles and audio recordings in multiple languages (Kunama, Tigrinya, Arabic and English).  It also documented atrocities such as the 2008 genocide against the Kunama people, ensuring that these events were not forgotten.

* **Affiliated organisations:**  Prominent links highlighted the **Eritrean Kunama Relief Association (ERKA)**, underscoring the solidarity between DMLEK’s political wing and the humanitarian efforts of ERKA.  The old site also shared contact information for supporters.

By archiving these materials, DMLEK kept the diaspora connected and informed.  This new site builds on that foundation with a cleaner design, improved navigation, a gallery featuring historical emblems and maps, and a content management system so that updates can be posted more easily.  If you explored the previous website, we hope you’ll recognise familiar themes here while enjoying the more modern experience.