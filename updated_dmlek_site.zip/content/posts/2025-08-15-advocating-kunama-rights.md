---
title: "Advocating for Kunama Rights and Self‑determination"
date: 2025-08-15
slug: advocating-kunama-rights
summary: "How DMLEK works to protect Kunama culture, language and autonomy through political and social action."
---

# Advocating for Kunama Rights and Self‑determination

At the core of DMLEK’s mission is the **right of the Kunama people to self‑determination**.  Kunama communities have a distinct culture and language, yet for decades they have been **denied meaningful representation** within the Eritrean state.

DMLEK promotes policies that protect **minority rights**, expand access to education and healthcare in Kunama areas, and encourage the preservation of traditional customs.  It also highlights human rights abuses committed against Kunama civilians by the Eritrean military and security forces.  Because DMLEK is largely funded by the **Eritrean diaspora**, it has the flexibility to operate independently of the Eritrean government.

The movement’s leaders emphasise that their struggle is not rooted in ethnic chauvinism.  Instead, they envision an **inclusive Eritrea** where diverse languages and cultures are celebrated and where no community is marginalised.  Achieving this vision will require continued advocacy, international solidarity and, if necessary, negotiation with the government.