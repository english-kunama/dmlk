---
title: "Alliance with the Red Sea Afar Democratic Organisation"
date: 2025-08-16
slug: alliance-with-rsado
summary: "Why DMLEK partners with the Red Sea Afar Democratic Organisation and what the alliance means for Eritrea’s opposition movement."
---

# Alliance with the Red Sea Afar Democratic Organisation

DMLEK is part of the **Eritrean Democratic Alliance**, a coalition of opposition groups seeking political change in Eritrea.  One of its principal allies is the **Red Sea Afar Democratic Organisation (RSADO)**, which represents the Afar people living along Eritrea’s southern coastline.

Both movements share similar objectives: to defend the rights of marginalised ethnic groups and to challenge the authoritarian practices of the Eritrean government.  By coordinating strategies and pooling resources, DMLEK and RSADO hope to amplify their impact.

This alliance has attracted support from segments of the **Eritrean diaspora** and international human rights groups.  It also underscores the inter‑ethnic solidarity that underpins Eritrea’s broader pro‑democracy movement.  Although the government labels both organisations as terrorist groups and has cracked down on their supporters, DMLEK and RSADO continue to advocate non‑violent solutions when possible and resist repression when necessary.