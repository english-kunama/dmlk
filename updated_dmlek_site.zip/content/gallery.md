---
title: "Gallery"
slug: gallery
---

# Gallery

Explore photographs that reflect the spirit of the Kunama people and the work of the Democratic Movement for the Liberation of the Eritrean Kunama (DMLEK). These images include our official emblems and flag as well as scenes from the African landscape that inspire our community.

<div class="gallery-grid">
  <img src="images/emblem.jpg" alt="DMLEK emblem" />
  <img src="images/kunama-flag.png" alt="Kunama flag" />
  <img src="images/kunamamap.gif" alt="Map of the ancestral land of the Kunama people" />
  <img src="images/erka.png" alt="Eritrean Kunama Relief Association (ERKA) logo" />
  <img src="images/erkavsdmlek.png" alt="DMLEK and ERKA solidarity emblem" />
  <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=800&q=60" alt="African landscape" />
  <img src="https://images.unsplash.com/photo-1543163521-1bf71f93e840?auto=format&fit=crop&w=800&q=60" alt="Countryside" />
</div>