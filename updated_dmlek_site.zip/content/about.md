---
title: "About DMLEK"
---

# About DMLEK

The **Democratic Movement for the Liberation of the Eritrean Kunama (DMLEK)** is a political and armed organisation established on **1 April 1995** to represent the interests of the Kunama people.  We arose in response to the marginalisation and discrimination our community has endured within Eritrea.

Our mission is to secure **self‑determination** for the Kunama people through peaceful advocacy and, when necessary, defensive action.  We strive to protect Kunama culture, language and land while promoting human rights and inclusive governance for all Eritreans.

DMLEK is part of the **Eritrean Democratic Alliance** and maintains strong partnerships with groups such as the **Red Sea Afar Democratic Organisation**.  We draw much of our strength from the **Eritrean diaspora**, whose support sustains our work.

We believe that a free and democratic Eritrea must respect and celebrate its diversity.  By upholding minority rights and encouraging inter‑ethnic solidarity, we aim to build a society where no community is left behind.