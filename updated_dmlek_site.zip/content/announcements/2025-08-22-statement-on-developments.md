---
title: "Statement on Recent Developments"
date: 2025-08-22
slug: statement-on-developments
summary: "DMLEK responds to reports about tensions in the Southern Red Sea region."
---

# Statement on Recent Developments

Reports have circulated regarding heightened tensions in the **Southern Red Sea region** of Eritrea.  DMLEK wishes to clarify that we remain committed to dialogue and peaceful resolution of disputes.  However, we also reaffirm our right to **defend our communities against aggression**.

We call on international organisations to monitor the situation closely and urge the Eritrean government to respect the rights of all ethnic groups.  Further updates will be shared as the situation evolves.