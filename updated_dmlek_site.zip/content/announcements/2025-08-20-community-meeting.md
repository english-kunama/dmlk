---
title: "Upcoming Kunama Community Meeting"
date: 2025-08-20
slug: community-meeting
summary: "Join us for a discussion on community needs and the future of our movement."
---

# Upcoming Kunama Community Meeting

The DMLEK leadership invites Kunama community members and supporters to a **virtual community meeting** on **25 August 2025**.  During the meeting we will discuss recent developments, share stories from the ground and brainstorm ways to strengthen our advocacy.

Please send questions or topics you would like to discuss in advance through our contact page.  We look forward to hearing from you!